#ifndef __mutexes_h__
#define __mutexes_h__

void init_mutexes();

#endif