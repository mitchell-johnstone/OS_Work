#ifndef __car_h__
#define __car_h__

void *carTask(void *args);

#endif
