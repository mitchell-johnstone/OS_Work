#ifndef __visitor_h__
#define __visitor_h__

void *visitorTask(void *args);

#endif
