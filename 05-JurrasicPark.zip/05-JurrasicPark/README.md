## Introduction

For this lab you will use threads, semaphores, and mutexes to implement a simulation of an ASCII art Jurassic Park!


