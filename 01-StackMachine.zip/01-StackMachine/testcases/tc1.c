#include <stdio.h>
#include "stackm.c"

int main() {
	stackm mystack;
	smInit(&mystack);
	return 0;
}
