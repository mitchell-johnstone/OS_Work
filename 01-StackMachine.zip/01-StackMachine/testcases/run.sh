#!/bin/bash
cat tc$1.c
gcc tc$1.c
./a.out
